#pragma once

#include <cstdint>
#include <cuda_runtime.h>
#include <ATen/core/Tensor.h>

// Launch the BOO SpMM kernel.  See BOO_FORMAT.md sec. 6.
//
// `threads` in {128, 256, 512} and `p` in {8, 16, 32} are swept, not fixed:
// `threads` is the 4x step lever on the shared-memory budget (128 -> 512
// quadruples it at identical 100% occupancy) and `p` is the linear one.
// Measured optimum for the row-segmented kernel: threads=256, p=64.
// (p=8, the original design point, is ~3x off it -- BOO_FORMAT.md sec. 12c/13.)
//
// The arena is sized from the format's GLOBAL maxima because `extern __shared__`
// takes one size for the whole grid -- CUDA has no per-CTA shared-memory size.
template <typename scalar_t>
void launch_boo_spmm(
    const int num_blocks,
    const int features,
    const int batch_size,
    const int rows,
    const int cols,
    const int max_nr,
    const int max_nc,
    const int max_nnz_blk,
    const int32_t* row_grp_ptr,
    const int32_t* row_ids,
    const int32_t* col_grp_ptr,
    const int32_t* col_ids,
    const int32_t* blk_row_grp,
    const int32_t* blk_col_grp,
    const int32_t* blk_nz_ptr,
    const uint8_t* blk_shift,
    const uint16_t* nz_idx,
    const scalar_t* nz_val,
    const scalar_t* X,
    scalar_t* Y,
    cudaStream_t stream = 0,
    int threads = 256,
    int p = 64,
    // row_seg: register-accumulating variant. Requires nz_order == rowmajor
    // (nz_idx sorted by local_row). Default; the caller falls back to false
    // for colmajor.
    bool row_seg = true,
    const int32_t* block_row_ptr = nullptr,
    const int32_t* row_starts = nullptr);

// Diagnostic-only upper-bound timing variant of launch_boo_spmm: the rowseg
// kernel's Step B+C atomicAdd -> plain store. Output incorrect by
// construction. fp32 only; row_seg-only; no precomputed row-boundary table.
// See boo_kernel.cu.
void launch_boo_diag_spmm(
    const int num_blocks,
    const int features,
    const int batch_size,
    const int rows,
    const int cols,
    const int max_nr,
    const int max_nc,
    const int max_nnz_blk,
    const int32_t* row_grp_ptr,
    const int32_t* row_ids,
    const int32_t* col_grp_ptr,
    const int32_t* col_ids,
    const int32_t* blk_row_grp,
    const int32_t* blk_col_grp,
    const int32_t* blk_nz_ptr,
    const uint8_t* blk_shift,
    const uint16_t* nz_idx,
    const float* nz_val,
    const float* X,
    float* Y,
    cudaStream_t stream = 0,
    int threads = 256,
    int p = 64);

// Zeroes Y then runs the plain (non-bucketed) three-way fork/join. Declared
// here (defined in bindings_boo.cu, alongside boo_spmm_cuda_impl which also
// calls it) so bindings_boo_timed.cu's BOOTimedSpMM can reuse the exact same
// production code path for its C++-only timing. See bindings_boo.cu.
template <typename scalar_t>
void boo_run_into(
    at::Tensor Y,
    int rows, int cols, int max_nr, int max_nc, int max_nnz_blk,
    const at::Tensor row_grp_ptr, const at::Tensor row_ids,
    const at::Tensor col_grp_ptr, const at::Tensor col_ids,
    const at::Tensor blk_row_grp, const at::Tensor blk_col_grp,
    const at::Tensor blk_nz_ptr, const at::Tensor blk_shift,
    const at::Tensor nz_idx, const at::Tensor nz_val,
    const at::Tensor rem_indptr, const at::Tensor rem_col_ind, const at::Tensor rem_vals,
    const at::Tensor tail_row, const at::Tensor tail_col, const at::Tensor tail_val,
    const at::Tensor X3, int threads, int p, int csr_mode, bool row_seg,
    cudaStream_t cur_stream, cudaStream_t block_stream,
    cudaStream_t csr_stream, cudaStream_t tail_stream
);

// Dynamic shared memory the launcher requests, in bytes.  Mirrors
// torch_fast_spdmm.boo.boo_arena_bytes so the Python occupancy model and the
// real launch cannot drift apart.
int boo_arena_bytes(int max_nr, int max_nc, int max_nnz_blk, int p, int scalar_bytes);
int boo_arena_bytes_rowseg(int max_nr, int max_nc, int max_nnz_blk, int p, int scalar_bytes);

// Launch the BOO tail kernel (BOO_TAIL_BATCH small_block_policy). Flat COO,
// no smem, grid-stride over tail_nnz so CTA count is bounded by occupancy
// rather than by tail_nnz -- see BOO_FORMAT.md sec. 15 / kernels/boo_kernel.cu.
template <typename scalar_t>
void launch_boo_tail_spmm(
    const int tail_nnz,
    const int features,
    const int batch_size,
    const int rows,
    const int cols,
    const int32_t* tail_row,
    const int32_t* tail_col,
    const scalar_t* tail_val,
    const scalar_t* X,
    scalar_t* Y,
    cudaStream_t stream = 0,
    int threads = 256);
